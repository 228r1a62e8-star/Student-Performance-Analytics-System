const API = "http://localhost:3000"; // backend URL

// Load all students
function loadStudents() {
    fetch(`${API}/students`)
        .then(res => res.json())
        .then(data => {
            const tbody = document.querySelector("#studentsTable tbody");
            tbody.innerHTML = "";

            data.forEach(std => {
                const row = `
                    <tr>
                        <td>${std.student_id}</td>
                        <td>${std.name}</td>
                        <td>${std.department || ''}</td>
                        <td>${std.year || ''}</td>
                    </tr>`;
                tbody.innerHTML += row;
            });
        })
        .catch(err => console.error(err));
}

// Get report card
function getReportCard() {
    const id = document.getElementById("reportId").value;
    if (!id) return alert('enter student id');

    fetch(`${API}/reports/report-card/${id}`)
        .then(res => {
            if (!res.ok) throw new Error('report not found');
            return res.json();
        })
        .then(data => {
            let html = `<h3>${data.student.name}</h3>`;
            html += `<p><strong>Aggregate (total marks):</strong> ${data.aggregate.total_marks || 0}</p>`;
            html += `<p><strong>Attendance (total):</strong> ${data.attendance ? ( (data.attendance.attended*100.0/data.attendance.total_classes).toFixed(2) ) + '%' : 'N/A'}</p>`;
            html += `<h4>Course-wise Marks:</h4><ul>`;
            data.marks.forEach(c => {
                html += `<li>${c.course_name}: ${c.marks}</li>`;
            });
            html += "</ul>";
            document.getElementById("reportOutput").innerHTML = html;
        })
        .catch(err => {
            console.error(err);
            alert('Could not load report');
        });
}

// Load Top Students
function loadTopStudents() {
    fetch(`${API}/reports/top-performers?n=5`)
        .then(res => res.json())
        .then(data => {
            const list = document.getElementById("topList");
            list.innerHTML = "";

            data.forEach(s => {
                list.innerHTML += `<li>${s.student_name || s.name} — ${ (s.percentage || s.percentage===0) ? (s.percentage+'%') : (s.percentage ? s.percentage : '') }</li>`;
            });
        })
        .catch(err => console.error(err));
}
