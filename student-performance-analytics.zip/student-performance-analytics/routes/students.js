// routes/students.js
const express = require('express');
const Router = express.Router;
const Database = require('better-sqlite3');
const path = require('path');

const router = Router();

// helper to open DB using path stored in app settings
function getDb(req) {
  const dbPath = req.app.get('dbPath') || path.join(__dirname, '..', 'db', 'student_performance.db');
  return new Database(dbPath, { readonly: false });
}

// GET /students   -> list all students with basic aggregate (avg marks & attendance)
router.get('/', (req, res) => {
  const db = getDb(req);
  try {
    // If a view 'student_summary' exists use it, otherwise compute simple aggregates
    const check = db.prepare("SELECT name FROM sqlite_master WHERE type='view' AND name='student_summary'").get();
    let rows;
    if (check) {
      rows = db.prepare("SELECT * FROM student_summary ORDER BY average_marks DESC").all();
    } else {
      rows = db.prepare(`
        SELECT s.student_id, s.name,
               ROUND(AVG(m.marks),2) AS average_marks,
               CASE WHEN SUM(a.total_classes) IS NULL OR SUM(a.total_classes)=0 THEN NULL
                    ELSE ROUND( SUM(a.attended)*100.0 / SUM(a.total_classes),2) END AS attendance_percentage
        FROM Students s
        LEFT JOIN Marks m ON s.student_id = m.student_id
        LEFT JOIN Attendance a ON s.student_id = a.student_id
        GROUP BY s.student_id
        ORDER BY average_marks DESC
      `).all();
    }
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db error' });
  } finally {
    db.close();
  }
});

// GET /students/:id -> detailed student info (profile + marks + attendance)
router.get('/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (!id) return res.status(400).json({ error: 'invalid id' });

  const db = getDb(req);
  try {
    const student = db.prepare('SELECT * FROM Students WHERE student_id = ?').get(id);
    if (!student) return res.status(404).json({ error: 'student not found' });

    const marks = db.prepare(`
      SELECT m.mark_id, m.course_id, c.course_name, m.marks
      FROM Marks m
      LEFT JOIN Courses c ON m.course_id = c.course_id
      WHERE m.student_id = ?
    `).all(id);

    const attendance = db.prepare(`
      SELECT a.attendance_id, a.course_id, c.course_name, a.total_classes, a.attended,
             CASE WHEN a.total_classes = 0 THEN NULL ELSE ROUND(a.attended*100.0/a.total_classes,2) END AS attendance_percent
      FROM Attendance a
      LEFT JOIN Courses c ON a.course_id = c.course_id
      WHERE a.student_id = ?
    `).all(id);

    res.json({ student, marks, attendance });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db error' });
  } finally {
    db.close();
  }
});

// POST /students  -> create new student
// body: { name, department, year }
router.post('/', (req, res) => {
  const { name, department, year } = req.body;
  if (!name) return res.status(400).json({ error: 'name required' });

  const db = getDb(req);
  try {
    const stmt = db.prepare('INSERT INTO Students (name, department, year) VALUES (?,?,?)');
    const info = stmt.run(name, department || null, year || null);
    const newStudent = db.prepare('SELECT * FROM Students WHERE student_id = ?').get(info.lastInsertRowid);
    res.status(201).json(newStudent);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db error' });
  } finally {
    db.close();
  }
});

// PUT /students/:id -> update basic profile
router.put('/:id', (req, res) => {
  const id = parseInt(req.params.id,10);
  const { name, department, year } = req.body;
  if (!id) return res.status(400).json({ error: 'invalid id' });

  const db = getDb(req);
  try {
    const stmt = db.prepare('UPDATE Students SET name = COALESCE(?, name), department = COALESCE(?, department), year = COALESCE(?, year) WHERE student_id = ?');
    stmt.run(name, department, year, id);
    const upd = db.prepare('SELECT * FROM Students WHERE student_id = ?').get(id);
    res.json(upd);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db error' });
  } finally {
    db.close();
  }
});

module.exports = router;
