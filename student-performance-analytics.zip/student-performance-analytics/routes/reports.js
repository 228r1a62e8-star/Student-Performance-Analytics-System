// routes/reports.js
const express = require('express');
const Router = express.Router;
const Database = require('better-sqlite3');
const path = require('path');

const router = Router();

function getDb(req) {
  const dbPath = req.app.get('dbPath') || path.join(__dirname, '..', 'db', 'student_performance.db');
  return new Database(dbPath, { readonly: false });
}

// GET /reports/report-card/:studentId
router.get('/report-card/:studentId', (req, res) => {
  const sid = parseInt(req.params.studentId, 10);
  if (!sid) return res.status(400).json({ error: 'invalid student id' });

  const db = getDb(req);
  try {
    const student = db.prepare('SELECT * FROM Students WHERE student_id = ?').get(sid);
    if (!student) return res.status(404).json({ error: 'student not found' });

    const marks = db.prepare(`
      SELECT c.course_id, c.course_name, m.marks
      FROM Marks m
      JOIN Courses c ON m.course_id = c.course_id
      WHERE m.student_id = ?
    `).all(sid);

    const aggregate = db.prepare(`
      SELECT 
        COUNT(m.mark_id) AS exam_count,
        SUM(m.marks) AS total_marks
      FROM Marks m
      WHERE m.student_id = ?
    `).get(sid);

    // attendance aggregate
    const attendance = db.prepare(`
      SELECT SUM(attended) AS total_attended, SUM(total_classes) AS total_classes
      FROM Attendance
      WHERE student_id = ?
    `).get(sid);

    const percentage = aggregate.total_marks && aggregate.exam_count ? (aggregate.total_marks / (aggregate.exam_count * 100) * 100) : null; // cautious

    res.json({
      student,
      marks,
      aggregate,
      attendance,
      calculated_overall_percentage: (aggregate.total_marks !== null && aggregate.exam_count > 0) ? Number(((aggregate.total_marks / (aggregate.exam_count * 100)) * 100).toFixed(2)) : null
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db error' });
  } finally {
    db.close();
  }
});

// GET /reports/top-performers?n=5
router.get('/top-performers', (req, res) => {
  const n = parseInt(req.query.n || '5', 10);
  const db = getDb(req);
  try {
    // If view exists use it, else compute
    const check = db.prepare("SELECT name FROM sqlite_master WHERE type='view' AND name='vw_student_percentage'").get();
    let rows;
    if (check) {
      rows = db.prepare("SELECT * FROM vw_student_percentage ORDER BY percentage DESC LIMIT ?").all(n);
    } else {
      rows = db.prepare(`
        SELECT s.student_id, s.name,
               ROUND(SUM(m.marks)*1.0 / NULLIF(COUNT(m.mark_id)*100,0) * 100,2) AS percentage
        FROM Students s
        LEFT JOIN Marks m ON s.student_id = m.student_id
        GROUP BY s.student_id
        ORDER BY percentage DESC
        LIMIT ?
      `).all(n);
    }
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db error' });
  } finally {
    db.close();
  }
});

// GET /reports/class-rank?class=10-A  (if you have 'class' column in Students)
router.get('/class-rank', (req, res) => {
  const cls = req.query.class;
  if (!cls) return res.status(400).json({ error: 'class required' });

  const db = getDb(req);
  try {
    // We assume Students table has a 'class' column; fallback if not present
    const hasClass = db.prepare("PRAGMA table_info('Students')").all().some(c => c.name === 'class');
    if (!hasClass) return res.status(400).json({ error: "Students table does not have a 'class' column in this DB" });

    const rows = db.prepare(`
      SELECT student_id, name, percentage FROM (
        SELECT s.student_id, s.name,
               ROUND(SUM(m.marks)*1.0 / NULLIF(COUNT(m.mark_id)*100,0) * 100,2) AS percentage
        FROM Students s
        LEFT JOIN Marks m ON s.student_id = m.student_id
        WHERE s.class = ?
        GROUP BY s.student_id
      ) t
      ORDER BY percentage DESC
    `).all(cls);

    // attach rank
    let rank = 0, lastPerc = null, same = 0;
    const withRank = rows.map(r => {
      if (r.percentage !== lastPerc) {
        rank = rank + 1 + same;
        same = 0;
        lastPerc = r.percentage;
      } else {
        same++;
      }
      return Object.assign({}, r, { rank });
    });

    res.json(withRank);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db error' });
  } finally {
    db.close();
  }
});

// GET /reports/attendance/:studentId?courseId=1
router.get('/attendance/:studentId', (req, res) => {
  const sid = parseInt(req.params.studentId, 10);
  if (!sid) return res.status(400).json({ error: 'invalid student id' });
  const courseId = req.query.courseId ? parseInt(req.query.courseId,10) : null;
  const db = getDb(req);
  try {
    if (courseId) {
      const rec = db.prepare('SELECT student_id, course_id, SUM(total_classes) AS total_classes, SUM(attended) AS attended FROM Attendance WHERE student_id = ? AND course_id = ? GROUP BY student_id, course_id').get(sid, courseId);
      if (!rec) return res.json({ student_id: sid, course_id: courseId, attendance_percent: null });
      rec.attendance_percent = rec.total_classes ? Number((rec.attended * 100.0 / rec.total_classes).toFixed(2)) : null;
      return res.json(rec);
    } else {
      const rec = db.prepare('SELECT student_id, SUM(total_classes) AS total_classes, SUM(attended) AS attended FROM Attendance WHERE student_id = ? GROUP BY student_id').get(sid);
      if (!rec) return res.json({ student_id: sid, attendance_percent: null });
      rec.attendance_percent = rec.total_classes ? Number((rec.attended * 100.0 / rec.total_classes).toFixed(2)) : null;
      return res.json(rec);
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db error' });
  } finally {
    db.close();
  }
});

module.exports = router;
