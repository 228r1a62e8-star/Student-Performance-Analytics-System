require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const studentsRouter = require('./routes/students');
const reportsRouter = require('./routes/reports');

const app = express();
app.use(cors());
app.use(express.json());

// static DB path check (db file should be at ./db/student_performance.db or set via env)
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'db', 'student_performance.db');
app.set('dbPath', DB_PATH);

// Health-check
app.get('/ping', (req, res) => res.json({ ok: true, db: DB_PATH }));

// Routers
app.use('/students', studentsRouter);
app.use('/reports', reportsRouter);

// Default 404
app.use((req, res) => res.status(404).json({ error: 'Not found' }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
