# Student Performance Analytics

Simple Student Performance Analytics backend using **SQLite** and **Express**.

## What you get
- SQLite database schema & sample data (`sql/`)
- Express REST API (`server.js`, `routes/`)
- Views & triggers ready for analytics
- Quick endpoints to get students, report-cards, top-performers, attendance

## Setup (local)

1. Clone repository or create folder and paste files.

2. Install dependencies:
```bash
npm install
```

3. Create SQLite DB (option A or B):

**A. Use existing DB file**  
Place `student_performance.db` inside `db/` folder (a prebuilt DB is included).

**B. Create DB from SQL scripts**  
If you do not have the `.db` file, create one and run:
```bash
sqlite3 db/student_performance.db < sql/schema.sql
sqlite3 db/student_performance.db < sql/sample_data.sql
sqlite3 db/student_performance.db < sql/views_triggers.sql
```
(Requires sqlite3 CLI to be installed)

4. Start server:
```bash
npm start
# or during development:
npm run dev
```

5. API endpoints:
- `GET /ping` — health check  
- `GET /students` — list students with averages  
- `GET /students/:id` — detailed student info (marks & attendance)  
- `POST /students` — create student `{ name, department, year }`  
- `GET /reports/report-card/:studentId` — report card  
- `GET /reports/top-performers?n=5` — top N performers  
- `GET /reports/attendance/:studentId?courseId=1` — attendance

## Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit - Student Performance Analytics"
git branch -M main
# create repo on GitHub then
git remote add origin https://github.com/<your-user>/<repo-name>.git
git push -u origin main
```

## Customize
- Add authentication & roles (admin/teacher)
- Add dashboard (React / Charting)
- Add pagination and filtering to API endpoints.
