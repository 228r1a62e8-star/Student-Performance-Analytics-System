-- views_triggers.sql

-- View: student_summary (average marks and attendance percent)
CREATE VIEW IF NOT EXISTS student_summary AS
SELECT 
  s.student_id,
  s.name AS student_name,
  ROUND(AVG(m.marks),2) AS average_marks,
  CASE WHEN SUM(a.total_classes) IS NULL OR SUM(a.total_classes) = 0 THEN NULL
       ELSE ROUND(SUM(a.attended)*100.0 / SUM(a.total_classes),2) END AS attendance_percentage
FROM Students s
LEFT JOIN Marks m ON s.student_id = m.student_id
LEFT JOIN Attendance a ON s.student_id = a.student_id
GROUP BY s.student_id;

-- View: course averages
CREATE VIEW IF NOT EXISTS vw_course_avg AS
SELECT c.course_id, c.course_name,
       COUNT(m.mark_id) AS num_records,
       ROUND(AVG(m.marks),2) AS avg_marks,
       ROUND(AVG(m.marks) / NULLIF(AVG(m.max_marks),0) * 100,2) AS avg_percentage
FROM Courses c
LEFT JOIN Marks m ON c.course_id = m.course_id
GROUP BY c.course_id;

-- View: student percentage
CREATE VIEW IF NOT EXISTS vw_student_percentage AS
SELECT s.student_id, s.name AS student_name,
       ROUND(SUM(m.marks)*1.0 / NULLIF(COUNT(m.mark_id)*100,0) * 100,2) AS percentage
FROM Students s
LEFT JOIN Marks m ON s.student_id = m.student_id
GROUP BY s.student_id;

-- Trigger: prevent inserting marks > max (assuming max_marks in row)
CREATE TRIGGER IF NOT EXISTS trg_validate_marks_insert
BEFORE INSERT ON Marks
BEGIN
  SELECT CASE WHEN NEW.marks > NEW.max_marks THEN
    RAISE(ABORT, 'Marks cannot exceed max_marks')
  END;
END;

CREATE TRIGGER IF NOT EXISTS trg_validate_marks_update
BEFORE UPDATE ON Marks
BEGIN
  SELECT CASE WHEN NEW.marks > NEW.max_marks THEN
    RAISE(ABORT, 'Marks cannot exceed max_marks')
  END;
END;

-- Trigger: low percentage alert (simple heuristic)
CREATE TRIGGER IF NOT EXISTS trg_low_percentage_after_insert
AFTER INSERT ON Marks
BEGIN
  -- compute percentage for student
  INSERT INTO Alerts(message)
  SELECT 'Low percentage alert for student_id=' || NEW.student_id || ' percentage=' || printf('%.2f', 
    (SELECT ROUND(SUM(marks)*1.0 / NULLIF(COUNT(mark_id)*100,0) * 100,2) FROM Marks WHERE student_id = NEW.student_id))
  WHERE (SELECT ROUND(SUM(marks)*1.0 / NULLIF(COUNT(mark_id)*100,0) * 100,2) FROM Marks WHERE student_id = NEW.student_id) < 50;
END;
