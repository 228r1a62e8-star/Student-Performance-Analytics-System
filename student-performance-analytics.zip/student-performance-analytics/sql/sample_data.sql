INSERT INTO Teachers (first_name, last_name, email) VALUES
('Rama','Kumar','rama.kumar@example.com'),
('Anita','Patel','anita.patel@example.com');

INSERT INTO Courses (course_name, code, credit_hours, teacher_id) VALUES
('Mathematics','MATH101',4,1),
('Physics','PHY101',4,1),
('Chemistry','CHEM101',4,2),
('English','ENG101',2,2);

INSERT INTO Students (name, roll_no, class, department, year, admission_date) VALUES
('Arjun Reddy','R001','10-A','Science',10,'2023-06-01'),
('Nikhil Sharma','R002','10-A','Science',10,'2023-06-01'),
('Priya Iyer','R003','10-A','Science',10,'2023-06-01'),
('Sneha K','R004','10-A','Science',10,'2023-06-01'),
('Rahul Verma','R005','10-A','Science',10,'2023-06-01');

-- Marks
INSERT INTO Marks (student_id, course_id, exam_date, max_marks, marks) VALUES
(1,1,'2024-03-15',100,85),
(1,2,'2024-03-16',100,78),
(1,3,'2024-03-17',100,91),
(1,4,'2024-03-18',100,88),

(2,1,'2024-03-15',100,92),
(2,2,'2024-03-16',100,89),
(2,3,'2024-03-17',100,76),
(2,4,'2024-03-18',100,84),

(3,1,'2024-03-15',100,70),
(3,2,'2024-03-16',100,66),
(3,3,'2024-03-17',100,72),
(3,4,'2024-03-18',100,75),

(4,1,'2024-03-15',100,58),
(4,2,'2024-03-16',100,62),
(4,3,'2024-03-17',100,55),
(4,4,'2024-03-18',100,60),

(5,1,'2024-03-15',100,95),
(5,2,'2024-03-16',100,94),
(5,3,'2024-03-17',100,98),
(5,4,'2024-03-18',100,96);

-- Attendance
INSERT INTO Attendance (student_id, course_id, date, total_classes, attended) VALUES
(1,1,'2024-03-10',5,4),
(1,2,'2024-03-10',5,4),
(2,1,'2024-03-10',5,5),
(2,2,'2024-03-10',5,5),
(3,1,'2024-03-10',5,3),
(4,1,'2024-03-10',5,2),
(5,1,'2024-03-10',5,5);
